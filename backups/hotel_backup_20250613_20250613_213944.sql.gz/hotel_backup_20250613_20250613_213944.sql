--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

-- Started on 2025-06-13 14:39:54 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS hoteldb;
--
-- TOC entry 3457 (class 1262 OID 16384)
-- Name: hoteldb; Type: DATABASE; Schema: -; Owner: hoteluser
--

CREATE DATABASE hoteldb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE hoteldb OWNER TO hoteluser;

\connect hoteldb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 856 (class 1247 OID 16440)
-- Name: BookingStatus; Type: TYPE; Schema: public; Owner: hoteluser
--

CREATE TYPE public."BookingStatus" AS ENUM (
    'CHECKED_IN',
    'CHECKED_OUT',
    'CANCELLED',
    'NO_SHOW'
);


ALTER TYPE public."BookingStatus" OWNER TO hoteluser;

--
-- TOC entry 853 (class 1247 OID 16434)
-- Name: IdType; Type: TYPE; Schema: public; Owner: hoteluser
--

CREATE TYPE public."IdType" AS ENUM (
    'PASSPORT',
    'NATIONAL_ID'
);


ALTER TYPE public."IdType" OWNER TO hoteluser;

--
-- TOC entry 847 (class 1247 OID 16408)
-- Name: RoomStatus; Type: TYPE; Schema: public; Owner: hoteluser
--

CREATE TYPE public."RoomStatus" AS ENUM (
    'CLEAN',
    'OCCUPIED',
    'DIRTY',
    'MAINTENANCE'
);


ALTER TYPE public."RoomStatus" OWNER TO hoteluser;

--
-- TOC entry 844 (class 1247 OID 16399)
-- Name: RoomType; Type: TYPE; Schema: public; Owner: hoteluser
--

CREATE TYPE public."RoomType" AS ENUM (
    'STANDARD',
    'SUPERIOR',
    'DELUXE',
    'FAMILY',
    'HOP_IN',
    'ZENITH'
);


ALTER TYPE public."RoomType" OWNER TO hoteluser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 214 (class 1259 OID 16389)
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: hoteluser
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO hoteluser;

--
-- TOC entry 218 (class 1259 OID 16857)
-- Name: pricing_history; Type: TABLE; Schema: public; Owner: hoteluser
--

CREATE TABLE public.pricing_history (
    id text NOT NULL,
    "roomType" public."RoomType" NOT NULL,
    "oldBasePrice" numeric(10,2) NOT NULL,
    "newBasePrice" numeric(10,2) NOT NULL,
    "oldBreakfastPrice" numeric(10,2) NOT NULL,
    "newBreakfastPrice" numeric(10,2) NOT NULL,
    reason text,
    "changedBy" text DEFAULT 'system'::text NOT NULL,
    "changedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.pricing_history OWNER TO hoteluser;

--
-- TOC entry 217 (class 1259 OID 16845)
-- Name: room_type_pricing; Type: TABLE; Schema: public; Owner: hoteluser
--

CREATE TABLE public.room_type_pricing (
    id text NOT NULL,
    "roomType" public."RoomType" NOT NULL,
    "basePrice" numeric(10,2) NOT NULL,
    "breakfastPrice" numeric(10,2) DEFAULT 250.00 NOT NULL,
    "seasonalMultiplier" numeric(4,2) DEFAULT 1.00 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "effectiveFrom" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "effectiveUntil" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.room_type_pricing OWNER TO hoteluser;

--
-- TOC entry 215 (class 1259 OID 16417)
-- Name: rooms; Type: TABLE; Schema: public; Owner: hoteluser
--

CREATE TABLE public.rooms (
    id text NOT NULL,
    "roomNumber" text NOT NULL,
    "roomType" public."RoomType" NOT NULL,
    floor integer NOT NULL,
    "basePrice" numeric(10,2) NOT NULL,
    status public."RoomStatus" DEFAULT 'CLEAN'::public."RoomStatus" NOT NULL,
    "maxOccupancy" integer DEFAULT 2 NOT NULL,
    features jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.rooms OWNER TO hoteluser;

--
-- TOC entry 216 (class 1259 OID 16447)
-- Name: walkin_bookings; Type: TABLE; Schema: public; Owner: hoteluser
--

CREATE TABLE public.walkin_bookings (
    id text NOT NULL,
    "bookingReference" text NOT NULL,
    "roomId" text NOT NULL,
    "guestFirstName" text NOT NULL,
    "guestLastName" text NOT NULL,
    "guestPhone" text NOT NULL,
    "guestIdType" public."IdType" NOT NULL,
    "guestIdNumber" text NOT NULL,
    "checkInDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "checkOutDate" timestamp(3) without time zone NOT NULL,
    "roomPrice" numeric(10,2) NOT NULL,
    "breakfastIncluded" boolean DEFAULT false NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    status public."BookingStatus" DEFAULT 'CHECKED_IN'::public."BookingStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.walkin_bookings OWNER TO hoteluser;

--
-- TOC entry 3447 (class 0 OID 16389)
-- Dependencies: 214
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: hoteluser
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
86c61af6-7cf8-42e7-ab98-2f38166718ee	7ca4c2c809741e3d2ce38e70b52c94827ead3d2f1224f0510b823a88854afc69	2025-06-13 14:09:03.715419+00	20250613113621_init	\N	\N	2025-06-13 14:09:03.708086+00	1
89cdbabd-0776-4127-88a6-6b8270b886dc	79953211dd6dfd11b95cb5270bf510287fda079ecfd71f22ef275849a32286e8	2025-06-13 14:09:03.718397+00	20250613115816_add_hop_in_zenith_rooms	\N	\N	2025-06-13 14:09:03.717288+00	1
bedbffde-b20a-4622-ab19-cbd082f87b7a	9bb3faa5ef0be16d266c08992ee330644913d3a47f68ed17d3437f60c327f88a	2025-06-13 14:09:03.724793+00	20250613131207_add_walkin_bookings	\N	\N	2025-06-13 14:09:03.71899+00	1
ee7e9388-61e1-44ae-8c25-3a4dd577353b	39404e7291a0058c8559ea1d2769bdd9656169e0755daf9b95bb125c50c2c1c2	2025-06-13 14:27:14.366286+00	20250613141500_add_pricing_system	\N	\N	2025-06-13 14:27:14.357001+00	1
\.


--
-- TOC entry 3451 (class 0 OID 16857)
-- Dependencies: 218
-- Data for Name: pricing_history; Type: TABLE DATA; Schema: public; Owner: hoteluser
--

COPY public.pricing_history (id, "roomType", "oldBasePrice", "newBasePrice", "oldBreakfastPrice", "newBreakfastPrice", reason, "changedBy", "changedAt") FROM stdin;
\.


--
-- TOC entry 3450 (class 0 OID 16845)
-- Dependencies: 217
-- Data for Name: room_type_pricing; Type: TABLE DATA; Schema: public; Owner: hoteluser
--

COPY public.room_type_pricing (id, "roomType", "basePrice", "breakfastPrice", "seasonalMultiplier", "isActive", "effectiveFrom", "effectiveUntil", "createdAt", "updatedAt") FROM stdin;
a026e7dd-f4c4-40ce-a889-e0020771ba1b	STANDARD	1200.00	250.00	1.00	t	2025-06-13 14:30:31.821	\N	2025-06-13 14:30:31.822	2025-06-13 14:30:31.822
fa18db0b-9a60-4b44-b92b-12e390ec9a1c	SUPERIOR	1800.00	250.00	1.00	t	2025-06-13 14:30:31.823	\N	2025-06-13 14:30:31.824	2025-06-13 14:30:31.824
94582eec-1719-4625-a663-ca091e56663c	DELUXE	2400.00	250.00	1.00	t	2025-06-13 14:30:31.824	\N	2025-06-13 14:30:31.825	2025-06-13 14:30:31.825
821b0f1c-951c-4753-8c27-bce60babe635	FAMILY	3200.00	250.00	1.00	t	2025-06-13 14:30:31.825	\N	2025-06-13 14:30:31.826	2025-06-13 14:30:31.826
75964aed-4ae9-4341-acc9-4c063fcfc430	HOP_IN	800.00	250.00	1.00	t	2025-06-13 14:30:31.826	\N	2025-06-13 14:30:31.827	2025-06-13 14:30:31.827
ae241c6e-551c-4baa-b554-ed27d8cf8143	ZENITH	5000.00	250.00	1.00	t	2025-06-13 14:30:31.827	\N	2025-06-13 14:30:31.828	2025-06-13 14:30:31.828
\.


--
-- TOC entry 3448 (class 0 OID 16417)
-- Dependencies: 215
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: hoteluser
--

COPY public.rooms (id, "roomNumber", "roomType", floor, "basePrice", status, "maxOccupancy", features, "createdAt", "updatedAt") FROM stdin;
08ed6344-debc-45f0-b9e1-5ec6582d1f39	301	DELUXE	3	0.00	CLEAN	3	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king", "minibar": true, "cityView": true}	2025-06-13 14:30:00.773	2025-06-13 14:30:00.773
2326923f-5e31-4c4b-95c6-5934ffe73bb3	303	STANDARD	3	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.777	2025-06-13 14:30:00.777
fe29f00d-0535-4ee4-ada1-8d841ebed823	304	STANDARD	3	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.778	2025-06-13 14:30:00.778
448cdd0e-22b2-416f-9192-0f8e63ffc4e1	305	STANDARD	3	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.778	2025-06-13 14:30:00.778
fd20638a-5447-48a3-a5ff-a42cdce96fdb	306	STANDARD	3	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.779	2025-06-13 14:30:00.779
ba8d783c-b3e3-4734-9807-051755486573	307	FAMILY	3	0.00	CLEAN	4	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king_twin", "minibar": true, "cityView": true}	2025-06-13 14:30:00.779	2025-06-13 14:30:00.779
ad5b735f-4384-424e-a314-3fe2804e70e9	302	STANDARD	3	0.00	OCCUPIED	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.776	2025-06-13 14:30:00.797
a74747eb-2418-4bd4-a774-3297d51c3d95	309	STANDARD	3	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.78	2025-06-13 14:30:00.78
c05c75cc-aae9-468b-8903-b7e2a6a558e7	310	STANDARD	3	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.781	2025-06-13 14:30:00.781
0d72f2ad-9c1c-4bd6-a20d-9a5ee383f86b	311	STANDARD	3	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.781	2025-06-13 14:30:00.781
53ccc6b6-1516-48b3-8a40-5a15f0246fa8	312	STANDARD	3	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.782	2025-06-13 14:30:00.782
8e2569ba-7226-4a15-873f-f9317fa7f189	313	STANDARD	3	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.782	2025-06-13 14:30:00.782
c4e5acb6-297b-41b3-9507-64055ea47af9	402	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.783	2025-06-13 14:30:00.783
043f13fc-390b-4751-9829-a7bbe03cdb6a	403	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.783	2025-06-13 14:30:00.783
da6ce610-3353-4af8-b95b-84e7e4436403	404	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.784	2025-06-13 14:30:00.784
69ad013b-baba-4921-a753-631fe04faa9f	405	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.784	2025-06-13 14:30:00.784
690cc55c-6c95-452d-98ca-812f643d1fc7	406	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.784	2025-06-13 14:30:00.784
511b4a59-9414-4224-b7fc-f0e655dacc4d	407	SUPERIOR	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": true, "cityView": true}	2025-06-13 14:30:00.785	2025-06-13 14:30:00.785
bb10be0b-3377-48ec-b90c-bb58b788378b	408	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.785	2025-06-13 14:30:00.785
5f171ddb-73fd-4892-a18d-dbce4b1c6515	410	FAMILY	4	0.00	CLEAN	4	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king_twin", "minibar": true, "cityView": true}	2025-06-13 14:30:00.786	2025-06-13 14:30:00.786
bd6f5ba3-867b-4685-a420-d0ae6f3a45f6	411	SUPERIOR	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": true, "cityView": true}	2025-06-13 14:30:00.786	2025-06-13 14:30:00.786
682fec3a-1432-4fe7-bfb4-746e76d1bd23	412	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.786	2025-06-13 14:30:00.786
e9eb0ea6-d3ee-438c-9701-04b1ae50938a	413	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.787	2025-06-13 14:30:00.787
aba3f18a-cbd7-4ec7-8106-3adb8d218142	414	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.787	2025-06-13 14:30:00.787
6a025321-52f3-480c-9f34-2136d79f993f	415	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.787	2025-06-13 14:30:00.787
5930a600-4f4a-42fb-b187-6142c3d5ae40	416	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.787	2025-06-13 14:30:00.787
d6552b1f-8033-4465-b87d-3c5adb673134	417	STANDARD	4	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.788	2025-06-13 14:30:00.788
fa5d576d-973a-495c-8e77-4230649f569a	418	DELUXE	4	0.00	CLEAN	3	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king", "minibar": true, "cityView": true}	2025-06-13 14:30:00.788	2025-06-13 14:30:00.788
1d56aadd-f2ac-47f4-b3ad-cbee6947eddb	501	DELUXE	5	0.00	CLEAN	3	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king", "minibar": true, "cityView": true}	2025-06-13 14:30:00.789	2025-06-13 14:30:00.789
994360e6-a23b-44e7-b376-2ba6ecfe7e8a	503	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.789	2025-06-13 14:30:00.789
0e99b79c-3338-4b53-ab87-03527adeb041	504	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.789	2025-06-13 14:30:00.789
fa632127-6695-4b46-b243-2722151bb4d5	505	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.79	2025-06-13 14:30:00.79
aedac107-4fb2-4060-bad4-01f9de405582	506	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.79	2025-06-13 14:30:00.79
69361761-a88d-425c-92bb-80b91a2465b6	507	SUPERIOR	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": true, "cityView": true}	2025-06-13 14:30:00.79	2025-06-13 14:30:00.79
d49d5e79-e92c-4cc5-824d-bc1bd1975701	508	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.791	2025-06-13 14:30:00.791
7f36f4ac-6e7b-43fa-ba0f-3bef91b9afc9	509	FAMILY	5	0.00	CLEAN	4	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king_twin", "minibar": true, "cityView": true}	2025-06-13 14:30:00.791	2025-06-13 14:30:00.791
42032c5d-aab5-4ca9-aa5e-aa03159391bb	510	FAMILY	5	0.00	CLEAN	4	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king_twin", "minibar": true, "cityView": true}	2025-06-13 14:30:00.791	2025-06-13 14:30:00.791
a35f757f-19fc-4cb6-b8fb-d0374d7619b5	511	FAMILY	5	0.00	CLEAN	4	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king_twin", "minibar": true, "cityView": true}	2025-06-13 14:30:00.791	2025-06-13 14:30:00.791
6efd8435-e0a3-4fc3-b9dc-5c9d16bd5b86	512	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.792	2025-06-13 14:30:00.792
bec7b6f6-619d-4df5-8901-40eaa8d7fcf7	513	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.792	2025-06-13 14:30:00.792
a68057a3-f539-452b-b12b-98c09db62eed	514	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.793	2025-06-13 14:30:00.793
227fb927-77b9-4514-b64c-c3b738b59c2d	515	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "twin", "minibar": false, "cityView": false}	2025-06-13 14:30:00.793	2025-06-13 14:30:00.793
492c0b1e-b1d6-4e13-9653-7a655306e3fe	516	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "double", "minibar": false, "cityView": false}	2025-06-13 14:30:00.794	2025-06-13 14:30:00.794
9afad0a8-7509-4147-9794-929c473d35fc	517	STANDARD	5	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.794	2025-06-13 14:30:00.794
a0df8be0-607a-42ca-93c0-d855ce04e3db	A 2-1	HOP_IN	3	0.00	CLEAN	1	{"tv": false, "wifi": true, "aircon": true, "balcony": false, "bedType": "single", "minibar": false, "cityView": false}	2025-06-13 14:30:00.794	2025-06-13 14:30:00.794
3c830ab1-62ab-4b7c-b470-fdaee41e9392	A 2-3	HOP_IN	3	0.00	CLEAN	1	{"tv": false, "wifi": true, "aircon": true, "balcony": false, "bedType": "single", "minibar": false, "cityView": false}	2025-06-13 14:30:00.795	2025-06-13 14:30:00.795
619059df-9dc8-4549-bdee-cb72b777c51c	A 3-2	HOP_IN	4	0.00	CLEAN	1	{"tv": false, "wifi": true, "aircon": true, "balcony": false, "bedType": "single", "minibar": false, "cityView": false}	2025-06-13 14:30:00.795	2025-06-13 14:30:00.795
368edf09-86d8-4875-942b-e9f63b8340be	A 3-3	HOP_IN	4	0.00	CLEAN	1	{"tv": false, "wifi": true, "aircon": true, "balcony": false, "bedType": "single", "minibar": false, "cityView": false}	2025-06-13 14:30:00.796	2025-06-13 14:30:00.796
58033a8e-48b3-4371-ad89-e4f677642261	A 4-1	HOP_IN	4	0.00	CLEAN	1	{"tv": false, "wifi": true, "aircon": true, "balcony": false, "bedType": "single", "minibar": false, "cityView": false}	2025-06-13 14:30:00.796	2025-06-13 14:30:00.796
d806afe1-b28f-4f93-874a-db1888a37dab	A 4-2	HOP_IN	4	0.00	CLEAN	1	{"tv": false, "wifi": true, "aircon": true, "balcony": false, "bedType": "single", "minibar": false, "cityView": false}	2025-06-13 14:30:00.796	2025-06-13 14:30:00.796
147660a8-d4ef-425d-930c-137fb926a7e1	A 4-3	HOP_IN	4	0.00	CLEAN	1	{"tv": false, "wifi": true, "aircon": true, "balcony": false, "bedType": "single", "minibar": false, "cityView": false}	2025-06-13 14:30:00.796	2025-06-13 14:30:00.796
1f5b4dc7-70dc-4af3-96f4-50c9c1f2356a	201	ZENITH	3	0.00	CLEAN	2	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king", "minibar": true, "cityView": true}	2025-06-13 14:30:00.797	2025-06-13 14:30:00.797
b11dbd45-7249-48e7-813d-e6e932363f77	308	SUPERIOR	3	0.00	OCCUPIED	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": true, "cityView": true}	2025-06-13 14:30:00.78	2025-06-13 14:30:00.797
a4c700bf-8d4f-4ca2-b730-8aeceef84454	401	DELUXE	4	0.00	OCCUPIED	3	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king", "minibar": true, "cityView": true}	2025-06-13 14:30:00.783	2025-06-13 14:30:00.797
733ffece-92e1-423c-90f1-24d8cf255344	409	FAMILY	4	0.00	OCCUPIED	4	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king_twin", "minibar": true, "cityView": true}	2025-06-13 14:30:00.785	2025-06-13 14:30:00.797
4e76f2d8-2275-4d6c-abae-cf7407d206c4	502	STANDARD	5	0.00	OCCUPIED	2	{"tv": true, "wifi": true, "aircon": true, "balcony": false, "bedType": "queen", "minibar": false, "cityView": false}	2025-06-13 14:30:00.789	2025-06-13 14:30:00.797
3f9df405-2891-4e89-ba88-3b4dc0c5f6fc	A 3-1	HOP_IN	4	0.00	OCCUPIED	1	{"tv": false, "wifi": true, "aircon": true, "balcony": false, "bedType": "single", "minibar": false, "cityView": false}	2025-06-13 14:30:00.795	2025-06-13 14:30:00.797
7311374f-cab4-4f1a-aaa4-b20a39903cc8	518	DELUXE	5	0.00	MAINTENANCE	3	{"tv": true, "wifi": true, "aircon": true, "balcony": true, "bedType": "king", "minibar": true, "cityView": true}	2025-06-13 14:30:00.794	2025-06-13 14:30:00.799
\.


--
-- TOC entry 3449 (class 0 OID 16447)
-- Dependencies: 216
-- Data for Name: walkin_bookings; Type: TABLE DATA; Schema: public; Owner: hoteluser
--

COPY public.walkin_bookings (id, "bookingReference", "roomId", "guestFirstName", "guestLastName", "guestPhone", "guestIdType", "guestIdNumber", "checkInDate", "checkOutDate", "roomPrice", "breakfastIncluded", "totalAmount", status, "createdAt") FROM stdin;
\.


--
-- TOC entry 3286 (class 2606 OID 16397)
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: hoteluser
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3302 (class 2606 OID 16865)
-- Name: pricing_history pricing_history_pkey; Type: CONSTRAINT; Schema: public; Owner: hoteluser
--

ALTER TABLE ONLY public.pricing_history
    ADD CONSTRAINT pricing_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3299 (class 2606 OID 16856)
-- Name: room_type_pricing room_type_pricing_pkey; Type: CONSTRAINT; Schema: public; Owner: hoteluser
--

ALTER TABLE ONLY public.room_type_pricing
    ADD CONSTRAINT room_type_pricing_pkey PRIMARY KEY (id);


--
-- TOC entry 3288 (class 2606 OID 16426)
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: hoteluser
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- TOC entry 3296 (class 2606 OID 16457)
-- Name: walkin_bookings walkin_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: hoteluser
--

ALTER TABLE ONLY public.walkin_bookings
    ADD CONSTRAINT walkin_bookings_pkey PRIMARY KEY (id);


--
-- TOC entry 3303 (class 1259 OID 16868)
-- Name: pricing_history_roomType_changedAt_idx; Type: INDEX; Schema: public; Owner: hoteluser
--

CREATE INDEX "pricing_history_roomType_changedAt_idx" ON public.pricing_history USING btree ("roomType", "changedAt");


--
-- TOC entry 3297 (class 1259 OID 16867)
-- Name: room_type_pricing_effectiveFrom_effectiveUntil_idx; Type: INDEX; Schema: public; Owner: hoteluser
--

CREATE INDEX "room_type_pricing_effectiveFrom_effectiveUntil_idx" ON public.room_type_pricing USING btree ("effectiveFrom", "effectiveUntil");


--
-- TOC entry 3300 (class 1259 OID 16866)
-- Name: room_type_pricing_roomType_isActive_idx; Type: INDEX; Schema: public; Owner: hoteluser
--

CREATE INDEX "room_type_pricing_roomType_isActive_idx" ON public.room_type_pricing USING btree ("roomType", "isActive");


--
-- TOC entry 3289 (class 1259 OID 16427)
-- Name: rooms_roomNumber_key; Type: INDEX; Schema: public; Owner: hoteluser
--

CREATE UNIQUE INDEX "rooms_roomNumber_key" ON public.rooms USING btree ("roomNumber");


--
-- TOC entry 3290 (class 1259 OID 16428)
-- Name: rooms_roomType_status_idx; Type: INDEX; Schema: public; Owner: hoteluser
--

CREATE INDEX "rooms_roomType_status_idx" ON public.rooms USING btree ("roomType", status);


--
-- TOC entry 3291 (class 1259 OID 16429)
-- Name: rooms_status_idx; Type: INDEX; Schema: public; Owner: hoteluser
--

CREATE INDEX rooms_status_idx ON public.rooms USING btree (status);


--
-- TOC entry 3292 (class 1259 OID 16459)
-- Name: walkin_bookings_bookingReference_idx; Type: INDEX; Schema: public; Owner: hoteluser
--

CREATE INDEX "walkin_bookings_bookingReference_idx" ON public.walkin_bookings USING btree ("bookingReference");


--
-- TOC entry 3293 (class 1259 OID 16458)
-- Name: walkin_bookings_bookingReference_key; Type: INDEX; Schema: public; Owner: hoteluser
--

CREATE UNIQUE INDEX "walkin_bookings_bookingReference_key" ON public.walkin_bookings USING btree ("bookingReference");


--
-- TOC entry 3294 (class 1259 OID 16460)
-- Name: walkin_bookings_guestPhone_idx; Type: INDEX; Schema: public; Owner: hoteluser
--

CREATE INDEX "walkin_bookings_guestPhone_idx" ON public.walkin_bookings USING btree ("guestPhone");


--
-- TOC entry 3304 (class 2606 OID 16461)
-- Name: walkin_bookings walkin_bookings_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hoteluser
--

ALTER TABLE ONLY public.walkin_bookings
    ADD CONSTRAINT "walkin_bookings_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public.rooms(id) ON UPDATE CASCADE ON DELETE RESTRICT;


-- Completed on 2025-06-13 14:39:54 UTC

--
-- PostgreSQL database dump complete
--

